import json
from datetime import datetime, timedelta
from collections import Counter, defaultdict
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def generate_and_send_daily_report():
    # ========== CONFIGURATION ==========
    YOUR_EMAIL = "mariyamkn04@gmail.com"
    APP_PASSWORD = "ylywwnlbwicsbfkg"  # Use your Gmail App Password here
    RECEIVER_EMAIL = "mariyamkn04@gmail.com"
    SESSION_FILE = "session_log.json"
    # ===================================

    # --- Load Session Data ---
    with open(SESSION_FILE, "r") as f:
        sessions = json.load(f)

    today_str = datetime.now().date().isoformat()
    today_sessions = [s for s in sessions if s["timestamp"].startswith(today_str)]
    total_sessions = len(today_sessions)

    # --- XP, Level, Streak Calculation ---
    xp = len(sessions)
    level = xp // 25 + 1

    # Calculate streak
    dates = sorted(set(s["timestamp"][:10] for s in sessions), reverse=True)
    streak = 0
    for i, date in enumerate(dates):
        day = datetime.strptime(date, "%Y-%m-%d").date()
        if i == 0:
            streak = 1
        else:
            prev_day = datetime.strptime(dates[i - 1], "%Y-%m-%d").date()
            if (prev_day - day).days == 1:
                streak += 1
            else:
                break

    # --- Mood Analysis ---
    mood_map = {"1": "😊 Good", "2": "😐 Neutral", "3": "😞 Bad"}
    mood_counter = Counter(mood_map.get(s["mood"], "Unknown") for s in today_sessions)

    # --- Time-of-Day Insights ---
    time_of_day = defaultdict(lambda: Counter())
    for s in today_sessions:
        dt = datetime.strptime(s["timestamp"], "%Y-%m-%d %H:%M:%S")
        hour = dt.hour
        mood = mood_map.get(s["mood"], "Unknown")

        if 7 <= hour <= 9:
            time_of_day["Morning (7am–9am)"][mood] += 1
        elif 10 <= hour <= 12:
            time_of_day["Late Morning (10am–12pm)"][mood] += 1
        elif 13 <= hour <= 16:
            time_of_day["Afternoon (1pm–4pm)"][mood] += 1
        elif 17 <= hour <= 20:
            time_of_day["Evening (5pm–8pm)"][mood] += 1
        else:
            time_of_day["Other Times"][mood] += 1

    # --- Top Tasks Today ---
    task_counter = Counter(s["task"] for s in today_sessions)

    # --- Visual XP Bar ---
    xp_bar = f"[{'█' * (xp % 100 // 10)}{'░' * (10 - (xp % 100 // 10))}] {xp % 100}/100 XP"

    # --- Report Generation ---
    report = []
    report.append(" Daily Productivity Insights Report\n")
    report.append(f" You completed {total_sessions} Pomodoro session(s) today.\n")

    report.append(" Mood Breakdown:")
    for mood, count in mood_counter.items():
        report.append(f"- {mood}: {count} sessions")
    report.append("")

    report.append(" Focus Time Insights:")
    for period, moods in time_of_day.items():
        mood_summary = ', '.join(f"{m}: {c}" for m, c in moods.items())
        report.append(f"- {period}: {mood_summary}")
    report.append("")

    report.append(" Top Tasks Today:")
    for task, count in task_counter.most_common(5):
        report.append(f"- {task}: {count} times")
    report.append("")

    report.append(" Focus Suggestion:\nYou're mentally sharpest in the morning. Try doing important tasks before 11am.\n")
    report.append(" Progress Overview:")
    report.append(f"XP Bar: {xp_bar}")
    report.append(f"Level: {level}")
    report.append(f"Streak: {streak} active days\n")
    report.append(f" Email sent to: {RECEIVER_EMAIL}")

    final_report = "\n".join(report)
    print(final_report)

    # --- Send Email ---
    message = MIMEMultipart()
    message["From"] = YOUR_EMAIL
    message["To"] = RECEIVER_EMAIL
    message["Subject"] = " Your Daily Pomodoro Productivity Report"

    body = MIMEText(final_report, "plain")
    message.attach(body)

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(YOUR_EMAIL, APP_PASSWORD)
            server.sendmail(YOUR_EMAIL, RECEIVER_EMAIL, message.as_string())
        print(" Email sent successfully!")
    except Exception as e:
        print(" Failed to send email:", str(e))
