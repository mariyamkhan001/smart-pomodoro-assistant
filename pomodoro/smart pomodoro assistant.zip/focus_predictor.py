import os
import json
from datetime import datetime
from sklearn.ensemble import RandomForestClassifier
import joblib
import pickle

SESSION_LOG = "session_log.json"
MODEL_FILE = "focus_model.pkl"

def load_focus_model():
    if os.path.exists(MODEL_FILE):
        return joblib.load(MODEL_FILE)
    else:
        # Fallback dummy model if not trained yet
        model = RandomForestClassifier()
        model.fit([[1, 25, 0]], [1])  # Dummy training with consistent encoding
        return model

def get_last_mood():
    try:
        with open(SESSION_LOG, 'r') as f:
            logs = json.load(f)
            if logs:
                return logs[-1].get("mood", None)
    except:
        pass
    return None

def predict_focus(priority, duration, time_of_day):
    priority_map = {"low": 0, "medium": 1, "high": 2}
    time_map = {"morning": 0, "afternoon": 1, "evening": 2, "night": 3}
    priority_encoded = priority_map.get(priority.lower(), 1)
    time_encoded = time_map.get(time_of_day.lower(), 1)

    X = [[priority_encoded, duration, time_encoded]]
    model = load_focus_model()
    mood_pred = model.predict(X)[0]

    # Return message based on numeric label
    if mood_pred == 2:
        return "🟢 High focus predicted! You're doing great. — keep going!"
    elif mood_pred == 1:
        return "🟡 Moderate focus. Stay focused, maybe add a reward!"
    else:  # mood_pred == 0
        return "🔴 Low focus predicted. Maybe take a short break first?"

def retrain_focus_model_from_logs():
    try:
        with open(SESSION_LOG, "r") as f:
            logs = json.load(f)

        moods = {"1": 2, "2": 1, "3": 0}  # Map your mood string to numeric labels

        X = []
        y = []
        for entry in logs:
            mood = entry.get("mood")
            if mood not in moods:
                print("Error processing log:", mood)
                continue
            timestamp = datetime.strptime(entry["timestamp"], "%Y-%m-%d %H:%M:%S")
            hour = timestamp.hour
            if hour < 12:
                tod = "morning"
            elif hour < 17:
                tod = "afternoon"
            elif hour < 21:
                tod = "evening"
            else:
                tod = "night"

            # For better model training, you should log priority and duration.
            # Since you don't have them, use placeholders or extend logging.
            # Here, I keep "medium" priority and 25 min duration as default:
            priority = "medium"
            duration = 25

            priority_encoded = {"high": 2, "medium": 1, "low": 0}.get(priority, 1)
            time_encoded = {"morning": 0, "afternoon": 1, "evening": 2, "night": 3}[tod]

            X.append([priority_encoded, duration, time_encoded])
            y.append(moods[mood])

        if X and y:
            model = RandomForestClassifier()
            model.fit(X, y)
            with open(MODEL_FILE, "wb") as f:
                pickle.dump(model, f)
            print("Focus model retrained using real session logs.")
        else:
            print("No valid session logs to retrain focus model.")
    except Exception as e:
        print("Error retraining model:", e)
