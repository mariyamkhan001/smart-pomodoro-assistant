import time
import json
import keyboard
from datetime import datetime, timedelta
import random
import sys
from focus_predictor import predict_focus, retrain_focus_model_from_logs
from daily_productivity_report import generate_and_send_daily_report

# === Theme Customization ===
THEME = "dark"

# === File Paths ===
TASK_FILE = "tasks.json"
SESSION_LOG = "session_log.json"
PROGRESS_FILE = "progress.json"

# === Theme ===
def set_theme():
    global THEME
    choice = input("Choose theme (light/dark): ").strip().lower()
    if choice in ["light", "dark"]:
        THEME = choice
    else:
        print("Invalid theme. Using default (dark).")

def styled_print(text):
    if THEME == "dark":
        color_code = "\033[38;5;10m"  # Lime green for dark mode
    else:
        color_code = "\033[38;5;111m"  # Blue for light mode
    print(f"{color_code}{text}\033[0m")


# === Sound Alert ===
def play_beep():
    print('\a')  # Terminal beep

def get_time_of_day():
    hour = datetime.now().hour
    if hour < 12:
        return "morning"
    elif hour < 17:
        return "afternoon"
    elif hour < 21:
        return "evening"
    else:
        return "night"


# === Motivation ===
def show_random_quote():
    try:
        with open("quotes.txt", "r", encoding="utf-8") as f:
            quotes = [line.strip() for line in f if line.strip()]
        if quotes:
            styled_print("\n Motivation: " + random.choice(quotes))
        else:
            styled_print("\n( No quotes found in quotes.txt)")
    except FileNotFoundError:
        styled_print("\n( quotes.txt not found)")

# === Task Management ===
def load_tasks():
    try:
        with open(TASK_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return []

def save_tasks(tasks):
    with open(TASK_FILE, 'w') as f:
        json.dump(tasks, f, indent=4)

def show_tasks(tasks):
    if not tasks:
        styled_print("No tasks found.")
    else:
        styled_print("\n--- Task List ---")
        for i, task in enumerate(tasks, start=1):
            deadline = task.get('deadline', 'None')
            priority = task.get('priority', 'medium')
            styled_print(f"{i}. {task['name']} (Deadline: {deadline}, Priority: {priority})")

def infer_priority(deadline_str):
    try:
        deadline = datetime.strptime(deadline_str, "%Y-%m-%d").date()
        days_left = (deadline - datetime.now().date()).days
        if days_left <= 1:
            return "high"
        elif days_left <= 4:
            return "medium"
        else:
            return "low"
    except:
        return "medium"

def patch_missing_priorities(tasks):
    for task in tasks:
        if 'priority' not in task:
            task['priority'] = infer_priority(task.get('deadline', ''))
    save_tasks(tasks)

def add_task(tasks):
    task_name = input("Enter new task: ")
    deadline = input("Enter deadline (YYYY-MM-DD) or leave blank: ").strip()
    priority = infer_priority(deadline)
    task = {"name": task_name, "deadline": deadline, "priority": priority}
    tasks.append(task)
    save_tasks(tasks)
    styled_print(f" Task added with inferred priority: {priority}")

def remove_task(tasks):
    show_tasks(tasks)
    choice = input("Enter task number to remove (or 'b' to go back): ").strip().lower()
    if choice == 'b':
        styled_print("Returning to main menu.")
        return
    try:
        i = int(choice) - 1
        if 0 <= i < len(tasks):
            tasks.pop(i)
            save_tasks(tasks)
            styled_print("Task removed successfully.")
        else:
            styled_print("Invalid task number.")
    except ValueError:
        styled_print("Please enter a valid number or 'b' to go back.")

def update_task(tasks):
    show_tasks(tasks)
    choice = input("Enter task number to update (or 'b' to go back): ").strip().lower()
    if choice == 'b':
        styled_print("Returning to main menu.")
        return
    try:
        i = int(choice) - 1
        if 0 <= i < len(tasks):
            new_name = input("Enter new task name (or 'b' to cancel): ").strip()
            if new_name.lower() == 'b':
                styled_print("Task update cancelled.")
                return
            tasks[i]['name'] = new_name
            save_tasks(tasks)
            styled_print("Task updated successfully.")
        else:
            styled_print("Invalid task number.")
    except ValueError:
        styled_print("Please enter a valid number or 'b' to go back.")

# === XP & Streak System ===
def load_progress():
    try:
        with open(PROGRESS_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {"xp": 0, "level": 1, "streak": 0, "last_active": None}

def update_progress():
    progress = load_progress()
    today = datetime.now().date().isoformat()
    progress['xp'] += 10
    if progress['xp'] >= 100:
        progress['level'] += 1
        progress['xp'] -= 100
        styled_print(f"🏆 Level Up! You're now Level {progress['level']}!")
    last_active = progress['last_active']
    if last_active:
        last_date = datetime.strptime(last_active, "%Y-%m-%d").date()
        if (datetime.now().date() - last_date).days == 1:
            progress['streak'] += 1
        elif (datetime.now().date() - last_date).days > 1:
            progress['streak'] = 1
    else:
        progress['streak'] = 1
    progress['last_active'] = today
    with open(PROGRESS_FILE, 'w') as f:
        json.dump(progress, f, indent=4)

def show_progress():
    progress = load_progress()
    styled_print(f" XP: {progress['xp']} |  Level: {progress['level']} | 🔥 Streak: {progress['streak']} days")

# === Pomodoro Timer ===
import keyboard

def start_timer(duration, label):
    styled_print(f"\n Timer Ready: {label} for {duration} minutes.")
    styled_print("Controls: Press 's' to start, 'p' to pause, 'r' to resume.")

    while True:
        if keyboard.is_pressed('s'):
            styled_print(" Timer started!")
            break

    minutes_passed = 0
    paused = False

    while minutes_passed < duration:
        if keyboard.is_pressed('p') and not paused:
            styled_print("⏸ Paused. Press 'r' to resume.")
            paused = True
            time.sleep(0.5)
            continue

        if paused:
            if keyboard.is_pressed('r'):
                styled_print(" Resumed.")
                paused = False
            time.sleep(0.5)
            continue

        # Progress bar update
        minutes_passed += 1
        done_blocks = int(minutes_passed / duration * 10)
        remaining_blocks = 10 - done_blocks
        bar = '🟩' * done_blocks + '🟪' * remaining_blocks

        print(" " * 80, end='\r')  # Clear line
        print(f"{bar}  {minutes_passed}/{duration} mins", end='\r', flush=True)

        time.sleep(60)# Simulate 1 minute (change to 2 for testing)

    print()  # Move to next line
    play_beep()
    show_random_quote()


def log_session(task_name):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    styled_print("\nHow was your session?")
    styled_print("1. 😊  Good")
    styled_print("2. 😐  Neutral")
    styled_print("3. 😞  Bad")

    mood_map = {"1": "😊", "2": "😐", "3": "😞"}
    mood_num = ""

    while mood_num not in mood_map:
        mood_num = input("Choose your mood (1/2/3): ").strip()
        if mood_num not in mood_map:
            styled_print(" Invalid input. Please choose 1, 2, or 3.")

    #  Save mood as number for model
    mood = mood_num

    log = {
        "task": task_name,
        "timestamp": timestamp,
        "mood": mood
    }

    try:
        with open(SESSION_LOG, 'r') as f:
            logs = json.load(f)
    except FileNotFoundError:
        logs = []

    logs.append(log)
    with open(SESSION_LOG, 'w') as f:
        json.dump(logs, f, indent=4)

    # 🟢 Still show emoji for user
    styled_print(f" Session logged with mood: {mood_map[mood]}")
    update_progress()
    show_progress()

    # 🔁 Retrain model using real data
    retrain_focus_model_from_logs()

# === View Session History ===
def view_session_history():
    try:
        with open(SESSION_LOG, 'r') as f:
            logs = json.load(f)
        styled_print("\n--- Session History ---")
        for entry in logs:
            mood = entry.get('mood', 'N/A')
            styled_print(f"{entry['timestamp']} - {entry['task']} - Mood: {mood}")
    except FileNotFoundError:
        styled_print("No session history found.")

# === Progress Summary ===
def view_progress_and_summary():
    show_progress()
    view_session_history()

# === Prioritization with Deadline and Priority ===
def prioritize_tasks(tasks):
    today = datetime.now().date()
    def score(task):
        deadline_str = task.get("deadline")
        priority = task.get("priority", "medium")
        try:
            days_left = (datetime.strptime(deadline_str, "%Y-%m-%d").date() - today).days if deadline_str else 30
        except:
            days_left = 30
        urgency_score = max(0, 30 - days_left) / 30
        priority_score = {"high": 1, "medium": 0.6, "low": 0.3}.get(priority, 0.5)
        return urgency_score + priority_score
    return sorted(tasks, key=score, reverse=True)

# === Suggest Duration Based on Combined Logic ===
def suggest_duration(task):
    deadline_str = task.get("deadline")
    priority = task.get("priority", "medium")
    try:
        days_left = (datetime.strptime(deadline_str, "%Y-%m-%d").date() - datetime.now().date()).days if deadline_str else 30
    except:
        days_left = 30
    if priority == "high" or days_left <= 2:
        return 45
    elif priority == "medium" or days_left <= 4:
        return 25
    else:
        return 15

# === Main Menu ===
def main():
    tasks = load_tasks()
    patch_missing_priorities(tasks)
    set_theme()

    while True:
        styled_print("\nPomodoro CLI")
        styled_print("1. Show Tasks")
        styled_print("2. Add Task")
        styled_print("3. Remove Task")
        styled_print("4. Update Task")
        styled_print("5. Start Prioritized Pomodoro")
        styled_print("6. View Session History")
        styled_print("7. Change Theme")
        styled_print("8. Progress Summary")
        styled_print("9. Daily Productivity Report")
        styled_print("0. Exit")

        choice = input("Choose an option: ").strip()

        if choice == '1':
            show_tasks(tasks)
        elif choice == '2':
            add_task(tasks)
        elif choice == '3':
            remove_task(tasks)
        elif choice == '4':
            update_task(tasks)
        elif choice == '5':
            prioritized = prioritize_tasks(tasks)
            if not prioritized:
                styled_print("No tasks available.")
                continue

            styled_print("\n Top Priority Task:")
            task = prioritized[0]
            styled_print(f"{task['name']} (Deadline: {task['deadline'] or 'None'}, Priority: {task['priority']})")

            while True:
                suggested = suggest_duration(task)
                time_of_day = get_time_of_day()
                prediction = predict_focus(task['priority'], suggested, time_of_day)

                if "low focus" in prediction.lower():
                    styled_print(f"\n Focus Prediction: {prediction}")
                    if task['priority'] == "high":
                        styled_print(" Low focus + High Priority: Setting duration to 25 minutes.")
                        suggested = 25
                    else:
                        styled_print(" Low focus detected. Reducing duration to 15 minutes.")
                        suggested = 15
                elif "high focus" in prediction.lower():
                    styled_print(f"\n Focus Prediction: {prediction}")
                    styled_print(" High focus detected! You can go full Pomodoro.")
                    suggested = max(suggested, 45)
                else:
                    styled_print(f"\n Focus Prediction: {prediction}")

                styled_print(f"⏱ Final Suggested Duration: {suggested} minutes")

                start_timer(suggested, f"Pomodoro - {task['name']}")
                log_session(task['name'])

                completed = input("Was this task completed? (y/n): ").strip().lower()
                if completed == 'y':
                    styled_print(f" Task '{task['name']}' marked as completed!")
                    tasks.remove(task)
                    save_tasks(tasks)
                    break
                else:
                    styled_print(" Task saved for later.")
                    followup = input("Do you want to:\n1. Start another Pomodoro\n2. Extend deadline\n3. Do nothing\nChoose (1/2/3): ").strip()
                    if followup == '1':
                        continue
                    elif followup == '2':
                        new_deadline = input("Enter new deadline (YYYY-MM-DD): ").strip()
                        task['deadline'] = new_deadline
                        task['priority'] = infer_priority(new_deadline)
                        save_tasks(tasks)
                        styled_print(" Deadline updated!")
                        break
                    else:
                        styled_print(" No changes made to the task.")
                        break

        elif choice == '6':
            view_session_history()
        elif choice == '7':
            set_theme()
        elif choice == '8':
            view_progress_and_summary()
        elif choice == '9':
            generate_and_send_daily_report()  # Make sure this function is defined/imported
        elif choice == '0':
            styled_print("Goodbye! Stay focused.")
            break
        else:
            styled_print("Invalid choice. Try again.")

# === Script Entry Point ===
if __name__ == "__main__":
    main()
