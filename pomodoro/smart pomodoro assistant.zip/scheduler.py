import time
from datetime import datetime, timedelta
from daily_productivity_report import generate_and_send_daily_report  # This is your report function

def wait_until_next_run(hour=1, minute=0):  # <-- Set to 1:00 AM
    while True:
        now = datetime.now()
        # Set target time for today at 1:00 AM
        target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if now > target:
            # If current time is past 1:00 AM, set target for next day
            target = target + timedelta(days=1)
        wait_seconds = (target - now).total_seconds()
        print(f"Waiting {int(wait_seconds)} seconds until {target.strftime('%Y-%m-%d %H:%M:%S')}")
        time.sleep(wait_seconds)  # Sleep until target time
        generate_and_send_daily_report()  # Call your email report function
        print("Report sent. Waiting for next day...")

if __name__ == "__main__":
    wait_until_next_run()  # Runs daily at 1:00 AM
